package com.pranavmore.IceCream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IceCreamApplication {

	public static void main(String[] args) {
		SpringApplication.run(IceCreamApplication.class, args);
	}

}
